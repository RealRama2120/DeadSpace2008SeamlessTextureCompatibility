# Changelog

## 1.0.0 — 2026-08-22

- First Nexus-ready release by Rama2120.
- Added one-click automatic TexMod 0.9b Package Mode setup and game launch.
- Added ordered multi-package `.tpf` loading with per-step verification.
- Added first-run configuration and automatic discovery of nearby user-supplied files.
- Added Steam library detection, EA App/Origin and installed-app registry detection, common-path checks on every fixed drive, and a full fixed-drive fallback scan.
- Added 32-bit PE validation to identify Dead Space (2008) and reject the 64-bit remake.
- Added out-of-sight TexMod automation with visible manual fallback on errors.
- Added game startup/load waiting, foreground handoff, clean TexMod shutdown, single-instance protection, and detailed logging.
- Added configurable UI delay and game-window timeout.
- Added controller-safe behavior: no mouse fix, input hook, or controller file is included or modified.
- Added DeadSpace2008Fixes, store-client, load-time, antivirus, and D3D-wrapper compatibility notes.
- Confirmed no TexMod executable or third-party texture package is included.
