# Dead Space Texture Launcher

One click to start **Dead Space (2008)** with your chosen TexMod `.tpf` texture packs already loaded.

Version 1.0.0  
Author: **Rama2120**

## What this does

- Finds the original 32-bit Dead Space automatically, including Steam and EA App/Origin installs.
- Checks Steam library folders and EA/Origin/installed-app registry entries.
- Checks common install paths on every fixed Windows drive, then performs a full fixed-drive scan only if needed.
- Rejects the 64-bit 2023 remake.
- Remembers your user-supplied `TexMod.exe` and `.tpf` files in the order you choose.
- Operates TexMod 0.9b's real Windows controls, loads every package, clicks Run, waits through long texture loading, and brings the game forward.
- Keeps TexMod out of sight during a normal launch and restores it if automation fails.
- Writes a detailed troubleshooting log.

The launcher does **not** contain TexMod, texture packs, game files, the old mouse fix, or any third-party DLL.

## Quick start

1. Extract the whole ZIP to a normal folder.
2. Run `DeadSpaceTextureLauncher.exe`.
3. On first run, let it find Dead Space or browse to the original game's `Dead Space.exe`.
4. Browse to your own copy of **TexMod 0.9b**.
5. Add one or more `.tpf` texture packs. Use **Move up** and **Move down** to set load order.
6. Choose **Save and launch**.

After setup, opening `DeadSpaceTextureLauncher.exe` launches the configured setup automatically. Hold **Shift** while opening it if you want to change settings without launching. You can also run:

```text
DeadSpaceTextureLauncher.exe --configure
```

You may place your own `TexMod.exe` next to the launcher and your own `.tpf` files in the included `TexturePacks` folder. The setup screen will notice them. They are never copied into a release automatically.

## Requirements

- Windows 10 or Windows 11. Windows 7 SP1 with .NET Framework 4.x may work but is not a supported target.
- Dead Space (2008), not the 2023 remake.
- A user-supplied 32-bit TexMod 0.9b executable.
- One or more user-supplied TexMod `.tpf` packages.
- Steam or EA App already signed in when the store copy requires it.

The launcher is a small 32-bit Windows executable compiled against the built-in .NET Framework. It does not require a development kit, PowerShell script, separate runtime download, installer, or network connection.

## Why it automates the TexMod window

Classic TexMod 0.9b has no supported command-line profile that can select a target executable, load an ordered set of `.tpf` files, and run the game. Passing made-up command-line flags is unreliable. This launcher therefore automates TexMod's normal Package Mode workflow.

It sends standard Win32 messages to known TexMod controls and verifies each step. It does not use blind screen coordinates, mouse movement, image matching, or fixed display scaling. A slower computer can use a larger **UI delay** in Settings.

This is intentionally a wrapper around an unmodified, user-supplied TexMod. It does not reimplement TexMod injection or patch the game executable.

## Steam and EA App notes

- Start and sign in to the store client first if the game normally needs it.
- TexMod starts `Dead Space.exe` directly. On some store/client configurations, the client may display its own launch or ownership error. Confirm the unmodded game launches normally, leave the client open, and try again.
- Do not rename or replace `Dead Space.exe` for this launcher.
- If TexMod is forced to run as administrator, Windows may block a normal launcher from controlling it. Remove that compatibility setting if possible. Otherwise, right-click this launcher and choose **Run as administrator** too.

## Controller-safe behavior

This launcher never installs or changes `dinput8.dll`, `xinput1_3.dll`, controller configuration, mouse configuration, or input hooks. In particular, it does **not** include the old Dead Space Mouse Fix that can interfere with controller look/aim.

## DeadSpace2008Fixes compatibility

DeadSpace2008Fixes can remain installed next to `Dead Space.exe`. This launcher does not replace its `xinput1_3.dll`, `SDL3.dll`, or `DeadSpaceFixes.ini`, and it launches the same game executable that the fix expects. That preserves the fix's modern-controller support and other improvements.

TexMod and DeadSpace2008Fixes both change game behavior at runtime, so test the game once with DeadSpace2008Fixes alone before adding texture packs. If you also use ReShade, DXVK, dgVoodoo, or another Direct3D 9 wrapper, troubleshoot those separately because multiple D3D hooks can conflict.

## Load order and waiting

Texture-pack order can matter when two packs replace the same texture. The launcher loads the top item first, exactly as shown in Settings.

Large `.tpf` packs can take several minutes to unpack inside the game process. A black screen or no visible game window during this time is not automatically a crash. The launcher waits, reports progress, and brings the game forward when its window appears. Do not start another copy or click Run again.

## Log and settings locations

```text
%LOCALAPPDATA%\Rama2120\DeadSpaceTextureLauncher\latest.log
%LOCALAPPDATA%\Rama2120\DeadSpaceTextureLauncher\settings.ini
```

The log contains paths, process IDs, control discovery, timings, and the exact failed step. It contains no passwords, account tokens, telemetry, or network activity.

## Troubleshooting

### The game was not detected

The launcher tries store data, every fixed drive's common paths, and finally a full fixed-drive scan. If the game is in an unusual protected folder, choose **Browse** and select its `Dead Space.exe` manually. A 64-bit executable is rejected because it is likely the remake.

### TexMod was left visible

That is the safe fallback. Read `latest.log`; then try these in order:

1. Confirm you selected classic 32-bit TexMod 0.9b.
2. Close all existing TexMod and Dead Space processes.
3. Increase **UI delay** from 400 ms to 700–1000 ms.
4. Remove mismatched administrator/compatibility settings.
5. Run TexMod manually once to see whether TexMod itself reports a game/client error.

### TexMod or antivirus reports a problem

TexMod injects textures into a Direct3D 9 game, so security software may scrutinize it. This release does not bundle TexMod and cannot vouch for copies downloaded elsewhere. Obtain it from a source you trust and scan it yourself. The launcher never downloads or whitelists anything.

### The game exits before showing a window

- Launch the unmodded game normally first.
- Make sure Steam or EA App is open and signed in.
- Test with one small `.tpf` pack.
- Temporarily remove other D3D wrappers from the equation.
- Open the log and note the last successful step.

## Uninstall

Delete the extracted launcher folder. To remove its small per-user configuration and log, delete:

```text
%LOCALAPPDATA%\Rama2120\DeadSpaceTextureLauncher
```

No game files need to be restored because this launcher never changes them.

## Distribution and permissions

The launcher's source code is MIT licensed. You may redistribute or modify the launcher under that license and should credit Rama2120.

TexMod, Dead Space, DeadSpace2008Fixes, and all texture packs are separate third-party works with their own owners and terms. Do not add any of them to a redistributed launcher archive unless you have explicit permission.

See `THIRD_PARTY_NOTICES.txt`, `LICENSE.txt`, and `Source` for details.
