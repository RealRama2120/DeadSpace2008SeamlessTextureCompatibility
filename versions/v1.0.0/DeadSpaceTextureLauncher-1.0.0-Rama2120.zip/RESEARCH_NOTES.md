# Automation research notes

## Conclusion

No supported classic TexMod 0.9b command line or persistent profile was found that can select a game executable, add an ordered list of `.tpf` packages, and launch in Package Mode. The safest practical method is to leave TexMod unmodified and automate its standard Windows controls.

The launcher therefore uses:

- TexMod 0.9b's stable Win32 control IDs when present.
- Button-text and observed z-order fallbacks for repacks that strip IDs.
- Standard `BM_CLICK` and `WM_SETTEXT` messages rather than screen coordinates.
- Standard Windows file-dialog IDs rather than localized button captions.
- State verification after selecting the game and after each package addition.
- An off-screen TexMod window during success and an on-screen restore on failure.

This is not fully headless: TexMod remains a GUI application internally. The wrapper makes that workflow effectively one-click without pretending unsupported command-line flags exist.

## Sources reviewed

- DeadSpace2008Fixes official repository and installation/controller notes:  
  https://github.com/seamusduncmcgrath/DeadSpace2008Fixes
- Archived open-source uMod documentation, reviewed only to distinguish uMod's templates/command-line launch features from classic TexMod 0.9b:  
  https://github.com/build-wars/texmod/blob/master/uMod_GUI/bin/README_English.txt
- Community TexMod automation showing the longstanding file-dialog workflow and classic control ordering:  
  https://archive.guildwarslegacy.com/thread?id=10335481
- Community Win32-message TexMod automation project, reviewed as prior-art evidence that control-message automation is more reliable than coordinate clicking:  
  https://github.com/mfrafael/TexModAutopilot

The last project had no license file at the time of review. Its code is not included in this release. This launcher's C# implementation, UI, game detection, safety behavior, packaging, and documentation were created for Rama2120 and are released under MIT.
