# Changelog

## 2.0.0 — 2026-08-23

- Redesigned the utility around normal Steam/EA Play-button launches.
- Added Steam `%command%` integration using a stable installed launcher copy without renaming Steam's game executable.
- Added EA App executable-proxy integration with x86/original validation, one-time UAC helper, transactional install, reversible removal, per-launch name swap, retry handling, and independent watchdog recovery.
- Added recursive `.tpf` discovery on every launch from the managed folder, launcher folder, game root, game `Mods`/`TexturePacks` folders, user-selected watched folders, and optionally Downloads.
- Added deterministic discovery ordering and duplicate-path removal.
- Added base-game passthrough when no `.tpf` files are present, so normal Play continues working before texture mods are installed.
- Added user-initiated TexMod 0.9b download from the archived original Google Code URL.
- Added pinned archive SHA-1 and extracted executable SHA-256 verification; mismatches are deleted and rejected.
- Kept TexMod out of the Nexus archive because no explicit redistribution license was found.
- Added automatic 1.x settings migration.
- Expanded setup, uninstall, recovery, antivirus, store-client, controller, and Nexus download instructions.
- Added a separate MIT-licensed `DeadSpaceTextureProxy.exe`; no input or graphics DLL is installed.

## 1.0.0 — 2026-08-22

- Initial standalone one-click launcher.
- Added Steam/EA game detection, fixed-drive fallback scanning, ordered package loading, Win32 TexMod control automation, logs, and controller-safe behavior.
