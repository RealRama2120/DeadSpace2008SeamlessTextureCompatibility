# Dead Space Seamless Texture Compatibility Launcher

Version **2.0.0**  
Author: **Rama2120**

Use `.tpf` texture mods with **Dead Space (2008)** while continuing to press the normal Play button in Steam or EA App. New extracted `.tpf` files are discovered on every launch, loaded into TexMod automatically, and injected before the game appears.

## What “seamless” means

After the one-time setup:

- **Steam:** Steam's normal Play button starts the texture launcher through a `%command%` Launch Option. The original game executable is not renamed.
- **EA App:** EA's normal Play button starts a small Rama2120 proxy. The verified original executable is restored to its canonical name before TexMod runs and the proxy is restored after the game closes.
- The user does not need to open TexMod, select the game, select packages, or remember a separate play shortcut.
- If no `.tpf` files are found, the verified base game launches normally without TexMod.

## First-time setup

1. Extract the entire release ZIP to a normal folder.
2. Run `DeadSpaceTextureLauncher.exe`.
3. Let setup find Dead Space (2008), or browse to `Dead Space.exe`.
4. Choose **Get verified TexMod 0.9b**, or browse to your own TexMod 0.9b executable.
5. Leave automatic TPF discovery enabled. The Downloads scan is enabled by default; disable it if you use TexMod for other games.
6. Choose **Install integration**.
7. Finish the store-specific step:
   - **Steam:** setup copies the exact Launch Option to the clipboard. In Steam, right-click Dead Space → **Properties** → **General** → **Launch Options**, then paste it once.
   - **EA App:** approve the one-time Windows administrator prompt. Setup preserves the original executable and installs the proxy automatically.
8. Save setup. From then on, use the regular Steam or EA Play button.

Steam's one-time paste is the same `%command%` technique used by the Dead Space 2 TexMod Autoloader. It avoids replacing the Steam game executable.

## How texture packs are found

The following locations are checked again **every launch**:

- Pinned `.tpf` files selected in Settings, in their chosen order.
- `%LOCALAPPDATA%\Rama2120\DeadSpaceTextureLauncher\TexturePacks` and all subfolders.
- The `TexturePacks` folder beside the launcher and all subfolders.
- `.tpf` files placed directly in the Dead Space game folder.
- `TexturePacks` and `Mods` folders inside the game folder, recursively.
- Any extra watched folders selected in Settings.
- The user's Downloads folder recursively when **Scan Downloads** is enabled.

New automatically discovered files are appended in alphabetical path order after pinned packages. Duplicate paths are removed.

Nexus downloads normally arrive as ZIP, RAR, or 7z archives. The archive must be extracted so an actual `.tpf` file exists. This launcher does not silently unpack or redistribute another author's archive.

The launcher cannot reliably determine which game an arbitrary `.tpf` was made for because the format does not require a game identifier. If you use TexMod for other games, disable Downloads scanning and put Dead Space packs in the managed TexturePacks folder instead.

## TexMod acquisition and licensing

TexMod is a separate third-party program created by RS/Racer_S. No explicit redistribution license for the original packed executable was found, so **TexMod.exe is not embedded in Rama2120's Nexus archive**.

To keep setup inclusive, the **Get verified TexMod 0.9b** button downloads `texmod.zip` directly from the archived original Google Code project on the user's computer. Before accepting it, the launcher verifies both:

```text
Original archive SHA-1:
c05a59ef20c5cb682230de2be9973945562ab86d

Extracted TexMod.exe SHA-256:
f662be61eee7c3d2849e1c734b3b83e9e25fa4e873c7352852130f0c0ceb98af
```

The downloaded executable is stored at:

```text
%LOCALAPPDATA%\Rama2120\DeadSpaceTextureLauncher\Tools\TexMod.exe
```

TexMod is unsigned, packed software from 2006 that injects into a Direct3D 9 process. Antivirus products may flag or quarantine it. The launcher never disables security software, creates an exclusion, accepts a checksum mismatch, or downloads TexMod without the user's explicit confirmation.

## Steam integration

Setup installs a stable launcher copy under the user's local application-data folder and generates this form of Launch Option:

```text
"%LOCALAPPDATA%\Rama2120\DeadSpaceTextureLauncher\App\DeadSpaceTextureLauncher.exe" --steam %command%
```

The actual line uses the expanded absolute path and is copied to the clipboard. Steam expands `%command%` to its normal Dead Space command. The wrapper loads textures and starts that verified game executable.

No Steam files, registry entries, or game executables are edited. To remove Steam integration, delete the custom Launch Option from Dead Space's Steam Properties.

## EA App integration and rollback safety

EA App does not provide Steam's `%command%` wrapper option. Setup therefore uses the established TexMod rename/swap approach with additional validation and recovery:

Idle installation:

```text
Dead Space.exe              Rama2120's small proxy
Dead Space.original.exe     Verified original 32-bit game
```

During a launch, after the proxy process exits:

1. A watchdog starts.
2. The proxy moves to `DeadSpaceTextureProxy.active.exe`.
3. The verified original moves back to `Dead Space.exe`.
4. TexMod targets and launches the correctly named original.
5. After the game exits, the original and proxy return to their idle names.

Every destructive step checks the exact filenames, x86 PE architecture, and Rama2120 proxy metadata. Existing backups are never overwritten. A failed install restores the original immediately. The watchdog restores the idle state if the main launcher is interrupted.

Use **Settings → Remove integration** before deleting the launcher. This restores the original `Dead Space.exe`. Keep `Dead Space.original.exe`; it is the original game, not disposable launcher data.

If a power loss interrupts the swap, the original may remain at `Dead Space.exe` and launch unmodded. Run setup again to repair integration; the original is deliberately left runnable rather than deleted.

## Controller-safe behavior

This project does not install or modify:

- `dinput8.dll`
- `xinput1_3.dll`
- controller profiles
- mouse settings
- the old Dead Space Mouse Fix

The normal-launch proxy is an executable, not an input DLL. It exits before the game starts.

## DeadSpace2008Fixes compatibility

DeadSpace2008Fixes can remain installed next to the game. This launcher does not replace its `xinput1_3.dll`, `SDL3.dll`, or `DeadSpaceFixes.ini`, preserving its modern controller support and other fixes.

Test DeadSpace2008Fixes alone first. TexMod, ReShade, DXVK, dgVoodoo, and similar tools all affect graphics at runtime; troubleshoot combinations one layer at a time.

## Loading and limits

Large `.tpf` packages can leave the game blank for several minutes while TexMod expands textures in the game process. The launcher waits, reports progress, and brings the game forward when its window appears. Do not press Play twice.

TexMod is a 32-bit 2006 application. Extremely large or conflicting package sets can exceed its practical memory limits or produce black/missing textures. Automatic discovery removes duplicate paths, but it cannot resolve texture conflicts between different packs.

## Logs and settings

```text
%LOCALAPPDATA%\Rama2120\DeadSpaceTextureLauncher\latest.log
%LOCALAPPDATA%\Rama2120\DeadSpaceTextureLauncher\settings.ini
%LOCALAPPDATA%\Rama2120\DeadSpaceTextureLauncher\App
%LOCALAPPDATA%\Rama2120\DeadSpaceTextureLauncher\TexturePacks
```

The launcher performs no telemetry. Network access occurs only when the user presses **Get verified TexMod 0.9b**.

## Troubleshooting

### Pressing Play bypasses the launcher

- Steam: verify the generated line is still present under Dead Space → Properties → Launch Options and includes `%command%`.
- EA App: run `DeadSpaceTextureLauncher.exe --configure` and use the integration repair/install button.

### A newly downloaded mod was not detected

- Extract the download and locate the actual `.tpf` file.
- Move it into the managed TexturePacks folder, the game's `Mods`/`TexturePacks` folder, or an enabled watched folder.
- If it remains in Downloads, confirm **Scan Downloads** is enabled.
- Open `latest.log`; it records the number of unique packages discovered.

### TexMod was left visible

That is the safe fallback. Close the game and TexMod, then inspect `latest.log`. Confirm TexMod 0.9b was selected, increase the UI delay, and remove mismatched administrator compatibility settings.

### EA integration cannot be installed

Close Dead Space, approve the Windows administrator prompt, and verify the game is not being updated. Setup will not overwrite an existing `Dead Space.original.exe`; use repair/removal first.

### Antivirus quarantines TexMod

Compare the reported hash with the pinned value above. Decide according to your own security policy. This project does not ask users to disable antivirus or trust a mismatched binary.

## Updating from 1.x

Run the 2.0.0 setup once. Existing game, TexMod, and pinned-package settings are preserved where possible, and the new setup adds automatic folders and normal Play-button integration.

## Uninstall

1. Open launcher Settings.
2. For EA App, choose **Remove integration** and confirm the original `Dead Space.exe` was restored.
3. For Steam, remove the custom Launch Option from Steam Properties.
4. Delete the extracted release folder.
5. Optionally delete `%LOCALAPPDATA%\Rama2120\DeadSpaceTextureLauncher` after saving any `.tpf` files kept in its TexturePacks folder.

## License and credits

Rama2120's launcher, proxy, installer logic, watchdog, and source code are MIT licensed. TexMod, Dead Space, DeadSpace2008Fixes, Nexus texture packs, and store clients are separate third-party works.

See `LICENSE.txt`, `THIRD_PARTY_NOTICES.txt`, `RESEARCH_NOTES.md`, and `Source`.
