# Research and design notes

## Dead Space 2 reference behavior

The referenced Dead Space 2 TexMod Autoloader does not transparently attach to every game process. Its optional seamless Steam route tells the user to put a wrapper in Steam's Launch Options:

```text
"full path to Launcher.exe" %command%
```

That established the safest Dead Space Steam design for this project. Version 2.0 installs a stable local launcher copy and generates the equivalent line with `--steam %command%`. It does not edit Steam configuration files or rename Steam's game executable.

Source:  
https://www.nexusmods.com/deadspace2/mods/84?tab=description

## EA/Origin constraint

Dead Space 2 community documentation describes the Origin chain as:

```text
Origin -> TexMod -> original game executable
```

It accomplishes this by renaming TexMod to the expected game filename, then restoring the original filename before TexMod launches it. Version 2.0 uses that same architectural requirement but substitutes a tiny Rama2120 proxy and adds validation, a persistent original backup, transactional failure rollback, runtime retry loops, removal support, and an independent watchdog.

Source:  
https://www.nexusmods.com/deadspace2/mods/4?file_id=92

## TexMod command-line limitation

Classic TexMod 0.9b has no supported command-line profile for selecting the target executable and ordered packages. The Guild Wars Wiki also records that TexMod does not support game command-line switches. Community autoloaders therefore automate its GUI.

Sources:  
https://wiki.guildwars.com/wiki/TexMod  
https://github.com/mfrafael/TexModAutopilot

This implementation sends Win32 control messages by stable control ID, uses structural fallbacks, controls standard Windows file dialogs without localized captions, and verifies target-title/package-list/process state. It does not use mouse coordinates.

## TexMod acquisition, checksum, and redistribution decision

The archived build-wars/texmod release page identifies the original `texmod.zip` and publishes SHA-1 `c05a59ef20c5cb682230de2be9973945562ab86d`. The Guild Wars Wiki publishes matching ZIP MD5/SHA-1 values and executable MD5/SHA-1 values. Independent file analysis identifies the matching 597,287-byte executable's SHA-256 as `f662be61eee7c3d2849e1c734b3b83e9e25fa4e873c7352852130f0c0ceb98af`.

Sources:  
https://github.com/build-wars/texmod/releases  
https://wiki.guildwars.com/wiki/TexMod

No explicit license granting redistribution of the original TexMod 0.9b packed executable was found. The Dead Space 2 autoloader's Nexus permissions also state that some assets belong to other authors and require their permission. Its uploader cannot relicense TexMod on behalf of RS.

Accordingly, Rama2120's archive does not contain TexMod. The user-initiated setup button downloads the original archive directly from the archived project, verifies the published archive SHA-1, extracts only TexMod.exe, verifies its pinned SHA-256, and rejects/deletes mismatches.

## Automatic TPF discovery boundary

The TPF format does not require a dependable game identifier, so loading every `.tpf` anywhere on a computer would be unsafe for people who mod multiple games. Version 2.0 scans explicit Dead Space locations, configurable folders, and optionally Downloads. It documents that archives must be extracted and that Downloads scanning should be disabled for multi-game TexMod users.

## Controller compatibility

The official DeadSpace2008Fixes repository documents its XInput/SDL3 controller support and `xinput1_3.dll` installation. This project avoids input DLL proxies entirely and uses an executable proxy only for EA's pre-launch chain.

Source:  
https://github.com/seamusduncmcgrath/DeadSpace2008Fixes
